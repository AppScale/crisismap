window = (typeof window === 'undefined') ? {} : window;
window['cm_build_info'] = {
  "release": false,
  "version": "b149c275d3b5 tip",
  "user": "romano",
  "path": "/private/tmp/foo"
};
